import { useCallback } from 'react';
import { useStore } from '../store/useStore';
import type { User } from '../types';
import type { BusinessProfile } from '../types/business';

interface BusinessUser {
  id: string;
  email: string;
  businessProfile: BusinessProfile;
}

export function useAuth() {
  const { user, setUser } = useStore();

  const login = useCallback(async (email: string, password: string): Promise<User | BusinessUser> => {
    // Demo business account
    if (email === 'info@mycakes.co.za') {
      const businessUser: BusinessUser = {
        id: 'b1',
        email: 'info@mycakes.co.za',
        businessProfile: {
          id: 'bp1',
          name: 'My Cakes',
          description: 'Artisanal cake shop specializing in custom celebrations',
          logo: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=200&h=200&q=80',
          category: 'Food & Beverage',
          locations: [{
            id: 'l1',
            name: 'My Cakes - Sandton',
            address: '123 Rivonia Road',
            city: 'Sandton',
            province: 'Gauteng',
            coordinates: {
              lat: -26.1052,
              lng: 28.0567
            }
          }],
          rewardsBudget: 25000,
          pointsMultiplier: 2
        }
      };
      setUser(businessUser);
      return businessUser;
    }

    // Regular user account (demo)
    const mockUser: User = {
      id: '1',
      name: 'John Doe',
      email,
      points: 1500,
      tier: 'Silver',
      spendingMilestones: {
        current: 7500,
        target: 10000
      },
      preferences: ['Shopping', 'Dining']
    };
    
    setUser(mockUser);
    return mockUser;
  }, [setUser]);

  const logout = useCallback(() => {
    setUser(null);
  }, [setUser]);

  return {
    user,
    login,
    logout,
    isAuthenticated: !!user
  };
}