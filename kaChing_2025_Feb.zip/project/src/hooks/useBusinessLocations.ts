import { useState, useEffect } from 'react';
import type { BusinessLocation, LocationFilters } from '../types/location';

export function useBusinessLocations(filters?: LocationFilters) {
  const [locations, setLocations] = useState<BusinessLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // In production, this would fetch from an API
    const mockLocations: BusinessLocation[] = [
      {
        ward: {
          code: "79800001",
          name: "Ward 1",
          municipality: "City of Johannesburg",
          district: "City of Johannesburg",
          province: "Gauteng"
        },
        address: "123 Main Road, Sandton",
        coordinates: { lat: -26.1052, lng: 28.0567 },
        isPrimary: true
      },
      {
        ward: {
          code: "79800015",
          name: "Ward 15",
          municipality: "City of Johannesburg",
          district: "City of Johannesburg",
          province: "Gauteng"
        },
        address: "456 Oak Avenue, Rosebank",
        coordinates: { lat: -26.1467, lng: 28.0437 },
        isPrimary: false
      }
    ];

    const filteredLocations = mockLocations.filter(location => {
      if (!filters) return true;
      
      return (
        (!filters.province || location.ward.province === filters.province) &&
        (!filters.district || location.ward.district === filters.district) &&
        (!filters.municipality || location.ward.municipality === filters.municipality) &&
        (!filters.ward || location.ward.code === filters.ward)
      );
    });

    setLocations(filteredLocations);
    setLoading(false);
  }, [filters]);

  return { locations, loading, error };
}