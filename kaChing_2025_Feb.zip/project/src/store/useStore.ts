import { create } from 'zustand';
import type { User, Reward, Transaction, Challenge } from '../types';
import { calculatePoints, calculateTier } from '../utils/rewards';

interface Store {
  user: User | null;
  rewards: Reward[];
  transactions: Transaction[];
  challenges: Challenge[];
  setUser: (user: User | null) => void;
  addTransaction: (transaction: Transaction) => void;
  updateChallenges: () => void;
}

export const useStore = create<Store>((set, get) => ({
  user: null, // Set initial user to null
  rewards: [
    {
      id: '1',
      title: 'R200 Woolworths Voucher',
      description: 'Get R200 off your next shopping trip at Woolworths',
      pointsCost: 2000,
      category: 'Shopping',
      merchant: 'Woolworths',
      imageUrl: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      featured: true,
      location: 'Sandton City, Johannesburg'
    },
    {
      id: '2',
      title: 'Nando\'s Family Feast',
      description: 'Enjoy a family feast at Nando\'s on us',
      pointsCost: 3000,
      category: 'Dining',
      merchant: 'Nando\'s',
      imageUrl: 'https://images.unsplash.com/photo-1532635241-17e820acc59f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      featured: true,
      location: 'Rosebank Mall, Johannesburg'
    },
    {
      id: '3',
      title: 'Movie Tickets for Two',
      description: 'Two movie tickets at Ster-Kinekor cinemas',
      pointsCost: 1500,
      category: 'Entertainment',
      merchant: 'Ster-Kinekor',
      imageUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      featured: true,
      location: 'Mall of Africa, Midrand'
    }
  ],
  transactions: [],
  challenges: [
    {
      id: '1',
      title: 'Shopping Spree',
      description: 'Spend R5000 at any retail store this month',
      target: 5000,
      progress: 2500,
      reward: 2000,
      expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      category: 'Shopping'
    }
  ],
  setUser: (user) => set({ user }),
  addTransaction: (transaction) => {
    const points = calculatePoints(transaction.amount);
    transaction.pointsEarned = points;
    
    set((state) => {
      const newTransactions = [transaction, ...state.transactions];
      const totalSpent = newTransactions.reduce((sum, t) => sum + t.amount, 0);
      const newTier = calculateTier(totalSpent);
      
      return {
        transactions: newTransactions,
        user: state.user ? {
          ...state.user,
          points: state.user.points + points,
          tier: newTier,
          spendingMilestones: {
            current: totalSpent,
            target: state.user.spendingMilestones.target
          }
        } : null
      };
    });
  },
  updateChallenges: () => {
    set((state) => {
      const updatedChallenges = state.challenges.map(challenge => {
        const relevantTransactions = state.transactions.filter(t => 
          t.category === challenge.category &&
          new Date(t.date) <= new Date(challenge.expiryDate)
        );
        
        const progress = relevantTransactions.reduce((sum, t) => sum + t.amount, 0);
        
        return {
          ...challenge,
          progress
        };
      });
      
      return { challenges: updatedChallenges };
    });
  }
}));