import React, { useState } from 'react';
import { PaymentMethodForm } from '../components/payment/PaymentMethodForm';
import { PaymentMethods } from '../components/payment/PaymentMethods';
import { PaymentHistory } from '../components/payment/PaymentHistory';
import type { PaymentMethod, PaymentHistory as PaymentHistoryType } from '../types/payment';

export function Payment() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: '1',
      type: 'card',
      last4: '4242',
      brand: 'Visa',
      expiryMonth: 12,
      expiryYear: 24,
      isDefault: true
    }
  ]);

  const [paymentHistory] = useState<PaymentHistoryType[]>([
    {
      id: '1',
      date: new Date().toISOString(),
      amount: 299.99,
      description: 'Monthly Subscription',
      status: 'completed',
      paymentMethod: '**** 4242'
    }
  ]);

  const handleAddPaymentMethod = (
    cardDetails: Partial<PaymentMethod>
  ) => {
    const newMethod: PaymentMethod = {
      id: Date.now().toString(),
      type: 'card',
      last4: cardDetails.last4 || '0000',
      brand: cardDetails.brand || 'Unknown',
      expiryMonth: cardDetails.expiryMonth || 0,
      expiryYear: cardDetails.expiryYear || 0,
      isDefault: false
    };

    setPaymentMethods(prev => [...prev, newMethod]);
  };

  const handleDeletePaymentMethod = (id: string) => {
    setPaymentMethods(prev => prev.filter(method => method.id !== id));
  };

  const handleSetDefaultPaymentMethod = (id: string) => {
    setPaymentMethods(prev =>
      prev.map(method => ({
        ...method,
        isDefault: method.id === id
      }))
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-white mb-8">Payment & Billing</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <PaymentMethods
            paymentMethods={paymentMethods}
            onDelete={handleDeletePaymentMethod}
            onSetDefault={handleSetDefaultPaymentMethod}
          />
          <PaymentHistory payments={paymentHistory} />
        </div>
        
        <div>
          <PaymentMethodForm
            onSubmit={(cardDetails) => handleAddPaymentMethod(cardDetails)}
          />
        </div>
      </div>
    </div>
  );
}