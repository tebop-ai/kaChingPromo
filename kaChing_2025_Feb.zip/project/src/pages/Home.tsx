import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { RewardCard } from '../components/RewardCard';
import { ChallengeCard } from '../components/challenges/ChallengeCard';
import { MilestoneTracker } from '../components/milestones/MilestoneTracker';
import { ReceiptScanner } from '../components/receipts/ReceiptScanner';
import { OffersSection } from '../components/offers/OffersSection';
import { TrendingUp, Gift, Target, Zap, Receipt, MapPin } from 'lucide-react';

export function Home() {
  const { user, challenges, rewards } = useStore();
  const featuredRewards = rewards.filter(reward => reward.featured);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Section */}
      <div className="bg-dark-800 border border-dark-700 rounded-lg p-6 text-white mb-8">
        <h1 className="text-2xl font-bold mb-2">Welcome back, {user?.name}!</h1>
        <p className="text-gray-400">You're on your way to amazing rewards.</p>
        
        {/* Weekly Participants Link */}
        <div className="flex justify-center mt-6">
          <Link
            to="/weekly-participants"
            className="inline-flex items-center px-6 py-3 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors text-xl font-medium"
          >
            <MapPin className="h-6 w-6 mr-2" />
            View This Week's Participating Businesses (Thurs 5 Dec to Wed 11 Dec)
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-dark-800 border border-dark-700 p-6 rounded-lg">
          <div className="flex items-center mb-2">
            <TrendingUp className="h-6 w-6 text-brand-500 mr-2" />
            <h2 className="text-lg font-semibold text-white">Points Balance</h2>
          </div>
          <p className="text-3xl font-bold text-brand-500">{user?.points}</p>
        </div>

        <div className="bg-dark-800 border border-dark-700 p-6 rounded-lg">
          <div className="flex items-center mb-2">
            <Gift className="h-6 w-6 text-brand-500 mr-2" />
            <h2 className="text-lg font-semibold text-white">Current Tier</h2>
          </div>
          <p className="text-3xl font-bold text-brand-500">{user?.tier}</p>
        </div>

        <div className="bg-dark-800 border border-dark-700 p-6 rounded-lg">
          <div className="flex items-center mb-2">
            <Target className="h-6 w-6 text-brand-500 mr-2" />
            <h2 className="text-lg font-semibold text-white">Next Tier</h2>
          </div>
          <p className="text-lg text-gray-400">R{user?.spendingMilestones.target - user?.spendingMilestones.current} to {user?.tier === 'Bronze' ? 'Silver' : user?.tier === 'Silver' ? 'Gold' : 'Platinum'}</p>
        </div>
      </div>

      {/* Receipt Scanner Section */}
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <Receipt className="h-6 w-6 text-brand-500 mr-2" />
          <h2 className="text-2xl font-bold text-white">Upload Receipt</h2>
        </div>
        <ReceiptScanner />
      </div>

      {/* Personalized Offers Section */}
      <div className="mb-8">
        <OffersSection />
      </div>

      {/* Challenges Section */}
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <Zap className="h-6 w-6 text-brand-500 mr-2" />
          <h2 className="text-2xl font-bold text-white">Active Challenges</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((challenge) => (
            <ChallengeCard key={challenge.id} challenge={challenge} />
          ))}
        </div>
      </div>

      {/* Milestones Section */}
      <div className="mb-8">
        <MilestoneTracker />
      </div>

      {/* Featured Rewards */}
      <h2 className="text-2xl font-bold text-white mb-4">Featured Rewards</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {featuredRewards.map((reward) => (
          <RewardCard
            key={reward.id}
            reward={reward}
            onRedeem={(reward) => {
              console.log('Redeeming reward:', reward);
              // Implement redemption logic
            }}
          />
        ))}
      </div>
    </div>
  );
}