import React from 'react';
import { Link } from 'react-router-dom';
import { Coins, ShoppingBag, LogIn, Target, Building2 } from 'lucide-react';

export function Landing() {
  return (
    <div className="min-h-screen bg-dark-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        {/* Hero Section */}
        <div className="text-center">
          <div className="flex justify-center items-center mb-8">
            <Coins className="h-24 w-24 text-brand-500" />
            <h1 className="text-6xl font-extrabold ml-4">
              <span className="text-white">ka'</span>
              <span className="bg-gradient-to-r from-brand-500 to-brand-600 text-transparent bg-clip-text">Ching</span>
              <span className="text-white">!</span>
            </h1>
          </div>
          <p className="text-2xl text-gray-300 mb-16 max-w-2xl mx-auto">
            Spend Smarter, Earn More ka'Ching!
          </p>
          
          {/* Main CTA - Smart Rewards */}
          <div className="bg-dark-800 border border-dark-700 rounded-2xl p-8 max-w-4xl mx-auto mb-12">
            <div className="flex items-center justify-center mb-8">
              <Target className="h-12 w-12 text-brand-500 mr-4" />
              <h2 className="text-3xl font-bold text-white">Spend R100 or more, stand to WIN R5000!</h2>
            </div>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <Link
                to="/login"
                className="inline-flex items-center justify-center px-8 py-4 text-lg font-semibold rounded-lg text-white bg-brand-600 hover:bg-brand-700 transition-colors"
              >
                <LogIn className="h-6 w-6 mr-2" />
                Login
              </Link>
              <Link
                to="/weekly-participants"
                className="inline-flex items-center justify-center px-8 py-4 text-lg font-semibold rounded-lg text-white bg-brand-600 hover:bg-brand-700 transition-colors"
              >
                <ShoppingBag className="h-6 w-6 mr-2" />
                Spend Here!
              </Link>
            </div>
          </div>

          {/* Partners Hub Button */}
          <div className="flex justify-center mt-12">
            <Link
              to="/business"
              className="inline-flex items-center justify-center px-8 py-4 text-lg font-semibold rounded-lg text-brand-500 border-2 border-brand-500 hover:bg-brand-500 hover:text-white transition-colors"
            >
              <Building2 className="h-5 w-5 mr-2" />
              Partners Hub
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}