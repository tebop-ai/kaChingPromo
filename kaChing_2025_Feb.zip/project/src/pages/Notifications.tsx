import React, { useState } from 'react';
import { Bell, Filter, CheckCircle } from 'lucide-react';
import { Card } from '../components/shared/Card';
import { NotificationsList } from '../components/notifications/NotificationsList';
import { NotificationFilters } from '../components/notifications/NotificationFilters';
import { NotificationPreferencesPanel } from '../components/notifications/NotificationPreferencesPanel';
import type { NotificationType } from '../types/notifications';

export function Notifications() {
  const [selectedTypes, setSelectedTypes] = useState<NotificationType[]>([]);
  const [showPreferences, setShowPreferences] = useState(false);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center">
          <Bell className="h-8 w-8 text-brand-500 mr-3" />
          <h1 className="text-3xl font-bold text-white">Notifications</h1>
        </div>
        <button
          onClick={() => setShowPreferences(!showPreferences)}
          className="flex items-center px-4 py-2 text-sm font-medium text-white bg-dark-800 rounded-lg hover:bg-dark-700 transition-colors"
        >
          <Filter className="h-4 w-4 mr-2" />
          Preferences
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <NotificationFilters
              selectedTypes={selectedTypes}
              onTypeSelect={setSelectedTypes}
            />
            <NotificationsList selectedTypes={selectedTypes} />
          </Card>
        </div>

        <div>
          {showPreferences ? (
            <NotificationPreferencesPanel />
          ) : (
            <Card>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
                <div className="space-y-4">
                  <button className="w-full flex items-center justify-between p-3 bg-dark-700 rounded-lg hover:bg-dark-600 transition-colors">
                    <span className="text-white">Mark all as read</span>
                    <CheckCircle className="h-5 w-5 text-brand-500" />
                  </button>
                  <button className="w-full flex items-center justify-between p-3 bg-dark-700 rounded-lg hover:bg-dark-600 transition-colors">
                    <span className="text-white">Clear all notifications</span>
                    <Bell className="h-5 w-5 text-brand-500" />
                  </button>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}