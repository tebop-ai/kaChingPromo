import React from 'react';
import { MapPin, Search } from 'lucide-react';
import { useLocation } from '../hooks/useLocation';
import { Card, CardHeader, CardTitle, CardContent } from '../components/shared/Card';
import { useStore } from '../store/useStore';
import type { Reward } from '../types';

export function Browse() {
  const { latitude, longitude, error, loading } = useLocation();
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState<string | null>(null);
  const rewards = useStore((state) => state.rewards);

  const categories = Array.from(new Set(rewards.map(reward => reward.category)));

  const filteredRewards = rewards.filter(reward => {
    const matchesSearch = reward.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reward.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reward.merchant.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || reward.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Location Status */}
      {loading && (
        <div className="mb-4 text-brand-500">
          <p>Requesting location access...</p>
        </div>
      )}
      {error && (
        <div className="mb-4 text-red-500">
          <p>{error}</p>
        </div>
      )}

      {/* Search and Filter */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search rewards..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-dark-800 border border-dark-700 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg ${
                !selectedCategory 
                  ? 'bg-brand-600 text-white' 
                  : 'bg-dark-800 text-gray-300 hover:bg-dark-700'
              }`}
            >
              All
            </button>
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                  selectedCategory === category 
                    ? 'bg-brand-600 text-white' 
                    : 'bg-dark-800 text-gray-300 hover:bg-dark-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Rewards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRewards.map((reward) => (
          <Card key={reward.id}>
            <CardHeader>
              <img
                src={reward.imageUrl}
                alt={reward.title}
                className="w-16 h-16 rounded-lg object-cover"
              />
              <div className="flex flex-col ml-4">
                <CardTitle>{reward.title}</CardTitle>
                <span className="text-sm text-gray-400">{reward.merchant}</span>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300">{reward.description}</p>
              {reward.location && (
                <div className="flex items-center text-sm text-gray-400 mt-2">
                  <MapPin className="h-4 w-4 mr-1" />
                  {reward.location}
                </div>
              )}
              <div className="mt-4 flex justify-between items-center">
                <div>
                  <p className="text-sm text-gray-400">Points required</p>
                  <p className="text-lg font-semibold text-white">{reward.pointsCost}</p>
                </div>
                <button className="bg-brand-600 text-white px-4 py-2 rounded-md hover:bg-brand-700 transition-colors">
                  Redeem
                </button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}