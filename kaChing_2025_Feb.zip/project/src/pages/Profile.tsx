import React from 'react';
import { Card } from '../components/shared/Card';
import { PersonalDetails } from '../components/profile/PersonalDetails';
import { NotificationPreferences } from '../components/profile/NotificationPreferences';
import { SecuritySettings } from '../components/profile/SecuritySettings';
import { TierProgress } from '../components/profile/TierProgress';
import { useStore } from '../store/useStore';

export function Profile() {
  const user = useStore((state) => state.user);

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-white mb-8">Profile Settings</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <PersonalDetails user={user} />
          <NotificationPreferences />
          <SecuritySettings />
        </div>
        
        <div>
          <TierProgress user={user} />
        </div>
      </div>
    </div>
  );
}