import React from 'react';
import { Building2, MapPin, CreditCard } from 'lucide-react';
import { Card } from '../../components/shared/Card';
import { LocationManager } from '../../components/business/LocationManager';
import { PaymentSection } from '../../components/business/PaymentSection';
import { useAuth } from '../../hooks/useAuth';

export function BusinessProfile() {
  const { user } = useAuth();
  const businessProfile = 'businessProfile' in user ? user.businessProfile : null;

  if (!businessProfile) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-white mb-8">Business Profile</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Business Information */}
        <div className="lg:col-span-2 space-y-8">
          <Card>
            <div className="p-6">
              <div className="flex items-center mb-6">
                <Building2 className="h-6 w-6 text-brand-500 mr-2" />
                <h2 className="text-xl font-semibold text-white">Business Information</h2>
              </div>
              
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Business Name
                  </label>
                  <input
                    type="text"
                    defaultValue={businessProfile.name}
                    className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Business Category
                  </label>
                  <select
                    defaultValue={businessProfile.category}
                    className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  >
                    <option value="retail">Retail</option>
                    <option value="food">Food & Beverage</option>
                    <option value="services">Services</option>
                    <option value="entertainment">Entertainment</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Description
                  </label>
                  <textarea
                    rows={4}
                    defaultValue={businessProfile.description}
                    className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </Card>

          {/* Locations */}
          <LocationManager />

          {/* Payment Settings */}
          <PaymentSection />
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          <Card>
            <div className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Quick Stats</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Total Locations</span>
                  <span className="text-white font-medium">{businessProfile.locations.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Rewards Budget</span>
                  <span className="text-white font-medium">R{businessProfile.rewardsBudget.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Points Multiplier</span>
                  <span className="text-white font-medium">{businessProfile.pointsMultiplier}x</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}