import React from 'react';
import { Heart, Share2, Users, Target } from 'lucide-react';
import { Card } from '../components/shared/Card';
import { SocialInitiative } from '../components/community/SocialInitiative';
import { DonationGoal } from '../components/community/DonationGoal';
import { FriendShare } from '../components/community/FriendShare';
import { useStore } from '../store/useStore';

export function CommunityHub() {
  const user = useStore((state) => state.user);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-white mb-4">Community Hub</h1>
        <p className="text-xl text-gray-300">Make a difference with your rewards</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Total Community Impact</p>
              <h3 className="text-2xl font-bold text-white">R125,000</h3>
              <p className="text-sm text-brand-500">Donated this month</p>
            </div>
            <Heart className="h-8 w-8 text-brand-500" />
          </div>
        </div>

        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Active Participants</p>
              <h3 className="text-2xl font-bold text-white">2,456</h3>
              <p className="text-sm text-brand-500">Contributing members</p>
            </div>
            <Users className="h-8 w-8 text-brand-500" />
          </div>
        </div>

        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Your Impact</p>
              <h3 className="text-2xl font-bold text-white">{user?.points || 0}</h3>
              <p className="text-sm text-brand-500">Points available</p>
            </div>
            <Target className="h-8 w-8 text-brand-500" />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Social Initiatives */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-2xl font-bold text-white mb-6">Featured Initiatives</h2>
          <SocialInitiative
            title="Education for All"
            description="Support local schools with essential supplies and resources"
            organization="SA Education Trust"
            goalAmount={50000}
            currentAmount={35000}
            imageUrl="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=1000&q=80"
          />
          <SocialInitiative
            title="Food Security Program"
            description="Help provide meals to vulnerable communities"
            organization="Feed SA Foundation"
            goalAmount={75000}
            currentAmount={45000}
            imageUrl="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1000&q=80"
          />
          <SocialInitiative
            title="Environmental Conservation"
            description="Support local wildlife conservation efforts"
            organization="Wildlife SA"
            goalAmount={30000}
            currentAmount={20000}
            imageUrl="https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1000&q=80"
          />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <DonationGoal />
          <FriendShare />
        </div>
      </div>
    </div>
  );
}