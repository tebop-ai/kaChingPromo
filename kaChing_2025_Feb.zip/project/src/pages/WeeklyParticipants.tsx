import React, { useState, useEffect } from 'react';
import { Search, MapPin, Filter } from 'lucide-react';
import { ParticipantCard } from '../components/participants/ParticipantCard';
import { useLocation } from '../hooks/useLocation';
import type { WeeklyParticipant } from '../types/participants';
import { calculateDistance } from '../utils/location';

export function WeeklyParticipants() {
  const { latitude, longitude, error: locationError } = useLocation();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [participants, setParticipants] = useState<WeeklyParticipant[]>([
    {
      id: '1',
      businessName: 'The Coffee Station',
      description: 'Artisanal coffee shop serving freshly roasted beans and homemade pastries',
      address: '123 Main Road, Sandton',
      coordinates: { lat: -26.1052, lng: 28.0567 },
      category: 'Café',
      hours: 'Mon-Fri: 7AM-6PM, Sat-Sun: 8AM-3PM',
      isOpen: true,
      website: 'https://thecoffeestation.co.za'
    },
    {
      id: '2',
      businessName: 'Fresh Harvest Market',
      description: 'Local grocery store specializing in fresh produce and organic goods',
      address: '45 Oak Avenue, Rosebank',
      coordinates: { lat: -26.1467, lng: 28.0437 },
      category: 'Grocery',
      hours: 'Mon-Sun: 8AM-8PM',
      isOpen: true
    },
    {
      id: '3',
      businessName: 'Urban Threads Boutique',
      description: 'Contemporary fashion boutique featuring local designers',
      address: '78 Fashion Street, Melrose Arch',
      coordinates: { lat: -26.1321, lng: 28.0671 },
      category: 'Fashion',
      hours: 'Mon-Sat: 9AM-6PM, Sun: 10AM-3PM',
      isOpen: true,
      website: 'https://urbanthreads.co.za'
    },
    {
      id: '4',
      businessName: 'Spice Route Kitchen',
      description: 'Authentic Indian cuisine using traditional family recipes',
      address: '234 Curry Lane, Fordsburg',
      coordinates: { lat: -26.2041, lng: 28.0232 },
      category: 'Restaurant',
      hours: 'Tue-Sun: 11AM-10PM',
      isOpen: true,
      website: 'https://spiceroutekitchen.co.za'
    },
    {
      id: '5',
      businessName: 'Tech Haven',
      description: 'Local electronics repair and accessories shop',
      address: '567 Digital Drive, Braamfontein',
      coordinates: { lat: -26.1925, lng: 28.0373 },
      category: 'Electronics',
      hours: 'Mon-Sat: 9AM-5PM',
      isOpen: true
    },
    {
      id: '6',
      businessName: 'Green Thumb Nursery',
      description: 'Garden center with indigenous plants and expert advice',
      address: '89 Flora Road, Parktown',
      coordinates: { lat: -26.1854, lng: 28.0418 },
      category: 'Garden',
      hours: 'Mon-Sun: 7AM-5PM',
      isOpen: true,
      website: 'https://greenthumb.co.za'
    },
    {
      id: '7',
      businessName: 'Bookworm Haven',
      description: 'Independent bookstore with rare finds and local authors',
      address: '321 Reader Street, Parkhurst',
      coordinates: { lat: -26.1367, lng: 28.0131 },
      category: 'Books',
      hours: 'Mon-Sat: 9AM-6PM, Sun: 10AM-2PM',
      isOpen: true
    },
    {
      id: '8',
      businessName: 'Fitness First Gym',
      description: 'Local fitness center with personal training and group classes',
      address: '444 Health Avenue, Illovo',
      coordinates: { lat: -26.1321, lng: 28.0524 },
      category: 'Fitness',
      hours: 'Mon-Sun: 5AM-9PM',
      isOpen: true,
      website: 'https://fitnessfirst.co.za'
    }
  ]);

  useEffect(() => {
    if (latitude && longitude) {
      setParticipants(prev => prev.map(participant => ({
        ...participant,
        distance: calculateDistance(
          latitude,
          longitude,
          participant.coordinates.lat,
          participant.coordinates.lng
        )
      })));
    }
  }, [latitude, longitude]);

  const categories = Array.from(new Set(participants.map(p => p.category)));

  const filteredParticipants = participants
    .filter(participant => {
      const matchesSearch = participant.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          participant.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = !selectedCategory || participant.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => (a.distance || 0) - (b.distance || 0));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">
          <span className="text-white">Spend </span>
          <span className="text-brand-500">R100 or more</span>
          <span className="text-white"> Here This Week</span>
        </h1>
        {locationError && (
          <div className="text-red-500">
            Please enable location services to see nearby businesses
          </div>
        )}
      </div>

      {/* Search and Filters */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search participating businesses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-dark-800 border border-dark-700 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                !selectedCategory 
                  ? 'bg-brand-600 text-white' 
                  : 'bg-dark-800 text-gray-300 hover:bg-dark-700'
              }`}
            >
              All Categories
            </button>
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                  selectedCategory === category 
                    ? 'bg-brand-600 text-white' 
                    : 'bg-dark-800 text-gray-300 hover:bg-dark-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Participants Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredParticipants.map((participant) => (
          <ParticipantCard key={participant.id} participant={participant} />
        ))}
      </div>
    </div>
  );
}