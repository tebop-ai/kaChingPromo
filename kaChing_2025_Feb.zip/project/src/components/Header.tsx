import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Coins, Heart, LogOut, Settings } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const isBusinessUser = user && 'businessProfile' in user;

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-dark-900 text-white border-b border-dark-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Coins className="h-8 w-8 text-brand-500" />
            <span className="font-bold text-xl">ka'Ching!</span>
          </Link>
          
          <div className="flex items-center space-x-6">
            {!isBusinessUser && (
              <Link to="/community" className="flex items-center hover:text-brand-500 transition-colors">
                <Heart className="h-5 w-5 mr-2" />
                <span>Community</span>
              </Link>
            )}
            
            {user && (
              <>
                <Link to={isBusinessUser ? "/business/profile" : "/profile"}>
                  <Settings className="h-6 w-6 hover:text-brand-500 transition-colors" />
                </Link>

                <button
                  onClick={handleLogout}
                  className="flex items-center hover:text-brand-500 transition-colors"
                >
                  <LogOut className="h-6 w-6" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}