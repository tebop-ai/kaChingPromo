import React from 'react';
import type { Reward } from '../types';
import { Gift } from 'lucide-react';

interface RewardCardProps {
  reward: Reward;
  onRedeem: (reward: Reward) => void;
}

export function RewardCard({ reward, onRedeem }: RewardCardProps) {
  return (
    <div className="bg-dark-800 rounded-lg shadow-xl overflow-hidden border border-dark-700">
      <img 
        src={reward.imageUrl} 
        alt={reward.title}
        className="w-full h-48 object-cover"
      />
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold text-white">{reward.title}</h3>
          <span className="flex items-center text-brand-500">
            <Gift className="h-4 w-4 mr-1" />
            {reward.pointsCost} points
          </span>
        </div>
        
        <p className="text-gray-400 text-sm mb-4">{reward.description}</p>
        
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-500">{reward.merchant}</span>
          <button
            onClick={() => onRedeem(reward)}
            className="bg-brand-600 text-white px-4 py-2 rounded-md hover:bg-brand-700 transition-colors"
          >
            Redeem
          </button>
        </div>
      </div>
    </div>
  );
}