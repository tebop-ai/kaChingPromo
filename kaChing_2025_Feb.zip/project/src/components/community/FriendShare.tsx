import React from 'react';
import { Share2, Gift } from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';

export function FriendShare() {
  const friends = [
    { id: '1', name: 'Sarah M.', points: 1200 },
    { id: '2', name: 'John D.', points: 850 },
    { id: '3', name: 'Mike R.', points: 2000 }
  ];

  return (
    <Card>
      <div className="flex items-center mb-6">
        <Share2 className="h-5 w-5 text-brand-500 mr-2" />
        <h3 className="text-lg font-bold text-white">Share with Friends</h3>
      </div>

      <div className="space-y-4">
        {friends.map((friend) => (
          <div
            key={friend.id}
            className="flex items-center justify-between p-3 bg-dark-700 rounded-lg"
          >
            <div>
              <p className="font-medium text-white">{friend.name}</p>
              <p className="text-sm text-gray-400">{friend.points} points</p>
            </div>
            <Button variant="outline" size="sm">
              <Gift className="h-4 w-4 mr-2" />
              Share
            </Button>
          </div>
        ))}
      </div>

      <button className="w-full mt-4 text-sm text-brand-500 hover:text-brand-400">
        View All Friends
      </button>
    </Card>
  );
}