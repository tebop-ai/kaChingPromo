import React from 'react';
import { Target } from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { useStore } from '../../store/useStore';

export function DonationGoal() {
  const user = useStore((state) => state.user);
  const monthlyGoal = 5000;
  const donated = 2500;
  const progress = (donated / monthlyGoal) * 100;

  return (
    <Card>
      <div className="flex items-center mb-4">
        <Target className="h-5 w-5 text-brand-500 mr-2" />
        <h3 className="text-lg font-bold text-white">Monthly Donation Goal</h3>
      </div>

      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-brand-500/10 mb-4">
          <span className="text-2xl font-bold text-brand-500">{Math.round(progress)}%</span>
        </div>
        <p className="text-sm text-gray-400">
          {donated.toLocaleString()} / {monthlyGoal.toLocaleString()} points
        </p>
      </div>

      <div className="w-full bg-dark-700 rounded-full h-2 mb-4">
        <div
          className="bg-brand-500 h-2 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      <Button variant="primary" className="w-full">
        Set New Goal
      </Button>
    </Card>
  );
}