import React from 'react';
import { Heart } from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';

interface SocialInitiativeProps {
  title: string;
  description: string;
  organization: string;
  goalAmount: number;
  currentAmount: number;
  imageUrl: string;
}

export function SocialInitiative({
  title,
  description,
  organization,
  goalAmount,
  currentAmount,
  imageUrl
}: SocialInitiativeProps) {
  const progress = (currentAmount / goalAmount) * 100;

  return (
    <Card>
      <div className="flex flex-col md:flex-row gap-6">
        <img
          src={imageUrl}
          alt={title}
          className="w-full md:w-48 h-48 object-cover rounded-lg"
        />
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
          <p className="text-gray-400 mb-4">{description}</p>
          <p className="text-sm text-brand-500 mb-4">By {organization}</p>

          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-dark-700 rounded-full h-2">
              <div
                className="bg-brand-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex justify-between text-sm text-gray-400 mt-2">
              <span>R{currentAmount.toLocaleString()}</span>
              <span>R{goalAmount.toLocaleString()}</span>
            </div>
          </div>

          <div className="flex gap-4">
            <Button variant="primary">
              <Heart className="h-4 w-4 mr-2" />
              Donate Points
            </Button>
            <Button variant="outline">Learn More</Button>
          </div>
        </div>
      </div>
    </Card>
  );
}