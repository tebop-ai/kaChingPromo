import React, { useState } from 'react';
import { Shield, Smartphone } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../shared/Card';
import { Button } from '../shared/Button';

export function SecuritySettings() {
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, this would update the password via API
    console.log('Updating password');
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <Shield className="h-6 w-6 text-brand-500 mr-2" />
          <CardTitle>Security Settings</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          {/* Two-Factor Authentication */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <Smartphone className="h-5 w-5 text-brand-500 mr-2" />
                <h3 className="text-lg font-medium text-white">Two-Factor Authentication</h3>
              </div>
              <div className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={twoFactorEnabled}
                  onChange={() => setTwoFactorEnabled(!twoFactorEnabled)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-dark-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-500/25 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-500"></div>
              </div>
            </div>
            <p className="text-sm text-gray-400">
              Add an extra layer of security to your account by enabling two-factor authentication.
            </p>
          </div>

          {/* Password Change */}
          <form onSubmit={handlePasswordChange} className="space-y-4">
            <h3 className="text-lg font-medium text-white mb-4">Change Password</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Current Password
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                New Password
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Confirm New Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" variant="primary">
                Update Password
              </Button>
            </div>
          </form>
        </div>
      </CardContent>
    </Card>
  );
}