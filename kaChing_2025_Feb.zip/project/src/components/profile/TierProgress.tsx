import React from 'react';
import { Award, TrendingUp } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../shared/Card';
import type { User } from '../../types';
import { getNextTierProgress } from '../../utils/rewards';

interface TierProgressProps {
  user: User;
}

export function TierProgress({ user }: TierProgressProps) {
  if (!user || !user.spendingMilestones) {
    return null;
  }

  const { next: nextTier, remaining } = getNextTierProgress(user.spendingMilestones.current);
  const progress = (user.spendingMilestones.current / user.spendingMilestones.target) * 100;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <Award className="h-6 w-6 text-brand-500 mr-2" />
          <CardTitle>Membership Tier</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-brand-500/10 mb-4">
            <Award className="h-10 w-10 text-brand-500" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">{user.tier}</h3>
          <p className="text-sm text-gray-400">Current Tier</p>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>Progress to {nextTier}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-dark-700 rounded-full h-2.5">
              <div
                className="bg-brand-500 h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
          </div>

          <div className="bg-dark-700 rounded-lg p-4">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-brand-500 mr-2" />
              <span className="text-sm text-gray-300">
                R{remaining.toLocaleString()} more to reach {nextTier}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-medium text-white">Tier Benefits:</h4>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Exclusive {user.tier} rewards</li>
              <li>• Priority customer support</li>
              <li>• {user.tier === 'Bronze' ? '1x' : user.tier === 'Silver' ? '1.5x' : user.tier === 'Gold' ? '2x' : '3x'} points multiplier</li>
              {user.tier !== 'Bronze' && <li>• Early access to promotions</li>}
              {(user.tier === 'Gold' || user.tier === 'Platinum') && <li>• VIP event invitations</li>}
              {user.tier === 'Platinum' && <li>• Personal rewards consultant</li>}
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}