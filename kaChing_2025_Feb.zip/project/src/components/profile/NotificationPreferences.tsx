import React, { useState } from 'react';
import { Bell } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../shared/Card';
import { Button } from '../shared/Button';

export function NotificationPreferences() {
  const [preferences, setPreferences] = useState({
    emailNotifications: true,
    pushNotifications: true,
    newRewards: true,
    pointsUpdates: true,
    specialOffers: true,
    weeklyDigest: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, this would update notification preferences via API
    console.log('Updating notification preferences:', preferences);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <Bell className="h-6 w-6 text-brand-500 mr-2" />
          <CardTitle>Notification Preferences</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            {Object.entries(preferences).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-300">
                  {key.split(/(?=[A-Z])/).join(' ')}
                </label>
                <div className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={value}
                    onChange={() => setPreferences(prev => ({ ...prev, [key]: !value }))}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-dark-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-500/25 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-500"></div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end">
            <Button type="submit" variant="primary">
              Save Preferences
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}