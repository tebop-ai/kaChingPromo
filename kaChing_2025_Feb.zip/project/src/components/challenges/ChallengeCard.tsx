import React from 'react';
import { Trophy, Clock } from 'lucide-react';
import type { Challenge } from '../../types';

interface ChallengeCardProps {
  challenge: Challenge;
}

export function ChallengeCard({ challenge }: ChallengeCardProps) {
  const progress = (challenge.progress / challenge.target) * 100;
  
  return (
    <div className="bg-dark-800 border border-dark-700 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold text-white">{challenge.title}</h3>
        <Trophy className={`h-6 w-6 ${progress === 100 ? 'text-brand-500' : 'text-gray-400'}`} />
      </div>
      
      <p className="text-gray-400 text-sm mb-4">{challenge.description}</p>
      
      <div className="mb-3">
        <div className="w-full bg-dark-700 rounded-full h-2.5">
          <div 
            className="bg-brand-500 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between mt-1 text-sm text-gray-400">
          <span>R{challenge.progress}</span>
          <span>R{challenge.target}</span>
        </div>
      </div>
      
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center text-gray-400">
          <Clock className="h-4 w-4 mr-1" />
          <span>Ends {new Date(challenge.expiryDate).toLocaleDateString()}</span>
        </div>
        <span className="font-semibold text-brand-500">+{challenge.reward} points</span>
      </div>
    </div>
  );
}