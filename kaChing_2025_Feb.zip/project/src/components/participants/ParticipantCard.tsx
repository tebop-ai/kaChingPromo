import React from 'react';
import { MapPin, Clock, ExternalLink } from 'lucide-react';
import { Card } from '../shared/Card';
import type { WeeklyParticipant } from '../../types/participants';

interface ParticipantCardProps {
  participant: WeeklyParticipant;
}

export function ParticipantCard({ participant }: ParticipantCardProps) {
  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-white">{participant.businessName}</h3>
          <span className={`px-3 py-1 rounded-full text-sm ${
            participant.isOpen ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'
          }`}>
            {participant.isOpen ? 'Open Now' : 'Closed'}
          </span>
        </div>
        
        <p className="text-gray-400 mb-4">{participant.description}</p>
        
        <div className="space-y-3">
          <div className="flex items-center text-gray-300">
            <MapPin className="h-5 w-5 text-brand-500 mr-2" />
            <span>{participant.address}</span>
          </div>
          
          <div className="flex items-center text-gray-300">
            <Clock className="h-5 w-5 text-brand-500 mr-2" />
            <span>{participant.hours}</span>
          </div>
        </div>

        <div className="mt-6 flex justify-between items-center">
          <div className="text-sm text-gray-400">
            {participant.distance && `${participant.distance.toFixed(1)} km away`}
          </div>
          {participant.website && (
            <a
              href={participant.website}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center text-brand-500 hover:text-brand-400"
            >
              Visit Website
              <ExternalLink className="h-4 w-4 ml-1" />
            </a>
          )}
        </div>
      </div>
    </Card>
  );
}