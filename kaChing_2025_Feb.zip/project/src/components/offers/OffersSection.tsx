import React from 'react';
import { Tag, TrendingUp, Clock } from 'lucide-react';
import { Card } from '../shared/Card';
import { useStore } from '../../store/useStore';
import { formatCurrency } from '../../utils/format';

interface Offer {
  id: string;
  title: string;
  description: string;
  category: string;
  discount: number;
  expiryDate: string;
  merchant: string;
  imageUrl: string;
  trending?: boolean;
}

export function OffersSection() {
  const user = useStore((state) => state.user);
  
  const offers: Offer[] = [
    {
      id: '1',
      title: 'Double Points Weekend',
      description: 'Earn 2x points on all purchases this weekend',
      category: 'retail',
      discount: 0,
      expiryDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
      merchant: 'All Stores',
      imageUrl: 'https://images.unsplash.com/photo-1607082349566-187342175e2f?auto=format&fit=crop&w=800&q=80',
      trending: true
    },
    {
      id: '2',
      title: '20% Off at Woolworths',
      description: 'Get 20% off your next purchase over R500',
      category: 'retail',
      discount: 20,
      expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      merchant: 'Woolworths',
      imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: '3',
      title: 'Free Coffee Upgrade',
      description: 'Size upgrade on any coffee purchase',
      category: 'dining',
      discount: 0,
      expiryDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
      merchant: 'Seattle Coffee Co.',
      imageUrl: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=800&q=80',
      trending: true
    }
  ].filter(offer => user?.preferences.some(pref => 
    offer.category.toLowerCase().includes(pref.toLowerCase())
  ));

  const trendingOffers = offers.filter(offer => offer.trending);

  return (
    <div className="space-y-8">
      {/* Trending Offers */}
      <div>
        <div className="flex items-center mb-4">
          <TrendingUp className="h-6 w-6 text-brand-500 mr-2" />
          <h2 className="text-2xl font-bold text-white">Trending Now</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trendingOffers.map((offer) => (
            <Card key={offer.id}>
              <div className="relative">
                <img
                  src={offer.imageUrl}
                  alt={offer.title}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <div className="absolute top-4 right-4">
                  <span className="bg-brand-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Trending
                  </span>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold text-white mb-2">{offer.title}</h3>
                <p className="text-gray-400 text-sm mb-4">{offer.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-sm text-gray-400">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>
                      Expires {new Date(offer.expiryDate).toLocaleDateString()}
                    </span>
                  </div>
                  <button className="bg-brand-600 text-white px-4 py-2 rounded-md hover:bg-brand-700 transition-colors">
                    Activate
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* All Offers */}
      <div>
        <div className="flex items-center mb-4">
          <Tag className="h-6 w-6 text-brand-500 mr-2" />
          <h2 className="text-2xl font-bold text-white">All Offers</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offers.map((offer) => (
            <Card key={offer.id}>
              <div className="relative">
                <img
                  src={offer.imageUrl}
                  alt={offer.title}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                {offer.discount > 0 && (
                  <div className="absolute top-4 right-4">
                    <span className="bg-brand-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {offer.discount}% Off
                    </span>
                  </div>
                )}
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold text-white mb-2">{offer.title}</h3>
                <p className="text-gray-400 text-sm mb-4">{offer.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-sm text-gray-400">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>
                      Expires {new Date(offer.expiryDate).toLocaleDateString()}
                    </span>
                  </div>
                  <button className="bg-brand-600 text-white px-4 py-2 rounded-md hover:bg-brand-700 transition-colors">
                    Activate
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}