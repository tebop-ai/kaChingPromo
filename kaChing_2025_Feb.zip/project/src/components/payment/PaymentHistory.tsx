import React from 'react';
import { Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../shared/Card';
import type { PaymentHistory as PaymentHistoryType } from '../../types/payment';

interface PaymentHistoryProps {
  payments: PaymentHistoryType[];
}

export function PaymentHistory({ payments }: PaymentHistoryProps) {
  const getStatusIcon = (status: PaymentHistoryType['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <Clock className="h-6 w-6 text-brand-500 mr-2" />
          <CardTitle>Payment History</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {payments.map((payment) => (
            <div
              key={payment.id}
              className="flex items-center justify-between p-4 bg-dark-700 rounded-lg"
            >
              <div>
                <p className="text-white font-medium">{payment.description}</p>
                <p className="text-sm text-gray-400">
                  {new Date(payment.date).toLocaleDateString()}
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-white font-medium">
                  R{payment.amount.toFixed(2)}
                </span>
                {getStatusIcon(payment.status)}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}