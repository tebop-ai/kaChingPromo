import React, { useState } from 'react';
import { CreditCard, MapPin } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../shared/Card';
import { Button } from '../shared/Button';
import type { PaymentMethod, BillingAddress } from '../../types/payment';

interface PaymentMethodFormProps {
  onSubmit: (cardDetails: Partial<PaymentMethod>, billingAddress: Partial<BillingAddress>) => void;
}

export function PaymentMethodForm({ onSubmit }: PaymentMethodFormProps) {
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    cardholderName: ''
  });

  const [billingAddress, setBillingAddress] = useState({
    street: '',
    city: '',
    province: '',
    postalCode: '',
    country: 'South Africa'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const formattedCard = {
      type: 'card' as const,
      last4: cardDetails.cardNumber.slice(-4),
      brand: detectCardBrand(cardDetails.cardNumber),
      expiryMonth: parseInt(cardDetails.expiryMonth),
      expiryYear: parseInt(cardDetails.expiryYear),
      isDefault: true
    };

    onSubmit(formattedCard, billingAddress);
  };

  const detectCardBrand = (number: string): string => {
    if (number.startsWith('4')) return 'Visa';
    if (number.startsWith('5')) return 'Mastercard';
    return 'Unknown';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <CreditCard className="h-6 w-6 text-brand-500 mr-2" />
          <CardTitle>Add Payment Method</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Card Details */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Card Number
              </label>
              <input
                type="text"
                maxLength={16}
                pattern="\d*"
                required
                className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={cardDetails.cardNumber}
                onChange={(e) => setCardDetails(prev => ({ ...prev, cardNumber: e.target.value }))}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Expiry Date
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="MM"
                    maxLength={2}
                    required
                    className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                    value={cardDetails.expiryMonth}
                    onChange={(e) => setCardDetails(prev => ({ ...prev, expiryMonth: e.target.value }))}
                  />
                  <input
                    type="text"
                    placeholder="YY"
                    maxLength={2}
                    required
                    className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                    value={cardDetails.expiryYear}
                    onChange={(e) => setCardDetails(prev => ({ ...prev, expiryYear: e.target.value }))}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  CVV
                </label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  value={cardDetails.cvv}
                  onChange={(e) => setCardDetails(prev => ({ ...prev, cvv: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Cardholder Name
              </label>
              <input
                type="text"
                required
                className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={cardDetails.cardholderName}
                onChange={(e) => setCardDetails(prev => ({ ...prev, cardholderName: e.target.value }))}
              />
            </div>
          </div>

          {/* Billing Address */}
          <div className="space-y-4">
            <div className="flex items-center">
              <MapPin className="h-5 w-5 text-brand-500 mr-2" />
              <h3 className="text-lg font-medium text-white">Billing Address</h3>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Street Address
              </label>
              <input
                type="text"
                required
                className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={billingAddress.street}
                onChange={(e) => setBillingAddress(prev => ({ ...prev, street: e.target.value }))}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  City
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  value={billingAddress.city}
                  onChange={(e) => setBillingAddress(prev => ({ ...prev, city: e.target.value }))}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Province
                </label>
                <select
                  required
                  className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  value={billingAddress.province}
                  onChange={(e) => setBillingAddress(prev => ({ ...prev, province: e.target.value }))}
                >
                  <option value="">Select Province</option>
                  <option value="gauteng">Gauteng</option>
                  <option value="western-cape">Western Cape</option>
                  <option value="kwazulu-natal">KwaZulu-Natal</option>
                  <option value="eastern-cape">Eastern Cape</option>
                  <option value="free-state">Free State</option>
                  <option value="mpumalanga">Mpumalanga</option>
                  <option value="limpopo">Limpopo</option>
                  <option value="north-west">North West</option>
                  <option value="northern-cape">Northern Cape</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Postal Code
              </label>
              <input
                type="text"
                required
                className="w-full px-4 py-2 rounded-lg bg-dark-700 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={billingAddress.postalCode}
                onChange={(e) => setBillingAddress(prev => ({ ...prev, postalCode: e.target.value }))}
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button type="submit" variant="primary">
              Add Payment Method
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}