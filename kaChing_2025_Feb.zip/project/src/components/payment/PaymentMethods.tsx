import React from 'react';
import { CreditCard, Trash2, CheckCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../shared/Card';
import { Button } from '../shared/Button';
import type { PaymentMethod } from '../../types/payment';

interface PaymentMethodsProps {
  paymentMethods: PaymentMethod[];
  onDelete: (id: string) => void;
  onSetDefault: (id: string) => void;
}

export function PaymentMethods({ paymentMethods, onDelete, onSetDefault }: PaymentMethodsProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <CreditCard className="h-6 w-6 text-brand-500 mr-2" />
            <CardTitle>Payment Methods</CardTitle>
          </div>
          <Button variant="outline" size="sm">
            Add New Card
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {paymentMethods.map((method) => (
            <div
              key={method.id}
              className="flex items-center justify-between p-4 bg-dark-700 rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="flex-shrink-0">
                  {method.brand === 'Visa' ? (
                    <span className="text-2xl">💳</span>
                  ) : (
                    <span className="text-2xl">💳</span>
                  )}
                </div>
                <div>
                  <p className="text-white font-medium">
                    {method.brand} ending in {method.last4}
                  </p>
                  <p className="text-sm text-gray-400">
                    Expires {method.expiryMonth}/{method.expiryYear}
                  </p>
                </div>
                {method.isDefault && (
                  <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-brand-500/10 text-brand-500">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Default
                  </span>
                )}
              </div>
              <div className="flex items-center space-x-2">
                {!method.isDefault && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onSetDefault(method.id)}
                  >
                    Set Default
                  </Button>
                )}
                <button
                  onClick={() => onDelete(method.id)}
                  className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}