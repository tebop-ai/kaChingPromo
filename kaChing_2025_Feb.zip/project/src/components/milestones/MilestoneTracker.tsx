import React from 'react';
import { Target, Award } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { getMilestoneProgress } from '../../utils/rewards';

export function MilestoneTracker() {
  const transactions = useStore((state) => state.transactions);
  const monthlySpending = getMilestoneProgress(transactions);
  const milestones = [
    { amount: 1000, reward: 500, achieved: monthlySpending >= 1000 },
    { amount: 2500, reward: 1500, achieved: monthlySpending >= 2500 },
    { amount: 5000, reward: 3500, achieved: monthlySpending >= 5000 },
  ];

  return (
    <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
      <div className="flex items-center mb-4">
        <Target className="h-6 w-6 text-brand-500 mr-2" />
        <h2 className="text-lg font-semibold text-white">Monthly Milestones</h2>
      </div>

      <div className="space-y-4">
        {milestones.map((milestone) => (
          <div key={milestone.amount} className="relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-300">
                Spend R{milestone.amount}
              </span>
              <div className="flex items-center">
                <Award className={`h-5 w-5 mr-1 ${milestone.achieved ? 'text-brand-500' : 'text-gray-500'}`} />
                <span className={`text-sm ${milestone.achieved ? 'text-brand-500 font-semibold' : 'text-gray-500'}`}>
                  +{milestone.reward} points
                </span>
              </div>
            </div>
            
            <div className="w-full bg-dark-700 rounded-full h-2.5">
              <div
                className="bg-brand-500 h-2.5 rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min((monthlySpending / milestone.amount) * 100, 100)}%`
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}