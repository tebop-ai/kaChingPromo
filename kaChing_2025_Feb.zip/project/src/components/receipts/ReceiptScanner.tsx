import React, { useState, useRef } from 'react';
import { Camera, Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { createWorker } from 'tesseract.js';
import * as tf from '@tensorflow/tfjs';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';

export function ReceiptScanner() {
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [verificationStatus, setVerificationStatus] = useState<'pending' | 'verified' | 'failed'>('pending');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const preprocessImage = async (imageData: ImageData) => {
    const tensor = tf.browser.fromPixels(imageData, 1);
    const normalized = tensor.div(255.0);
    const threshold = normalized.greater(0.5);
    return threshold;
  };

  const validateReceipt = async (text: string): Promise<boolean> => {
    // Implement receipt validation logic
    const hasDate = /\d{1,2}[-/]\d{1,2}[-/]\d{2,4}/.test(text);
    const hasAmount = /R\s*\d+([.,]\d{2})?/.test(text);
    const hasItemList = text.split('\n').length > 5;
    const hasTotalSection = /total|subtotal|amount/i.test(text);
    
    return hasDate && hasAmount && hasItemList && hasTotalSection;
  };

  const detectFraud = async (imageData: ImageData): Promise<boolean> => {
    // Implement fraud detection using TensorFlow.js
    try {
      const tensor = await preprocessImage(imageData);
      
      // Check for digital manipulation signatures
      const edges = tf.conv2d(
        tensor.expandDims(0).expandDims(-1),
        tf.randomNormal([3, 3, 1, 1]),
        1,
        'valid'
      );
      
      const variance = tf.moments(edges).variance.dataSync()[0];
      const isManipulated = variance < 0.1; // Threshold for detecting digital manipulation
      
      tensor.dispose();
      edges.dispose();
      
      return !isManipulated;
    } catch (error) {
      console.error('Fraud detection error:', error);
      return false;
    }
  };

  const handleScan = async (file: File) => {
    try {
      setScanning(true);
      setError(null);
      
      // Create canvas context for image processing
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) return;

      // Load and draw image
      const img = new Image();
      img.src = URL.createObjectURL(file);
      await new Promise((resolve) => {
        img.onload = resolve;
      });

      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);

      // Get image data for processing
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

      // Perform fraud detection
      const isLegitimate = await detectFraud(imageData);
      if (!isLegitimate) {
        setVerificationStatus('failed');
        throw new Error('Potential fraudulent receipt detected');
      }

      // Perform OCR
      const worker = await createWorker();
      await worker.loadLanguage('eng');
      await worker.initialize('eng');
      const { data: { text } } = await worker.recognize(file);
      await worker.terminate();

      // Validate receipt content
      const isValid = await validateReceipt(text);
      if (!isValid) {
        setVerificationStatus('failed');
        throw new Error('Invalid receipt format');
      }

      setResult(text);
      setVerificationStatus('verified');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to scan receipt');
      setVerificationStatus('failed');
    } finally {
      setScanning(false);
    }
  };

  return (
    <Card>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Receipt Scanner</h3>
        
        <div className="space-y-6">
          {/* Upload Area */}
          <div
            className="border-2 border-dashed border-dark-600 rounded-lg p-8 text-center"
            onDragOver={(e) => e.preventDefault()}
            onDrop={async (e) => {
              e.preventDefault();
              const file = e.dataTransfer.files[0];
              if (file) await handleScan(file);
            }}
          >
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleScan(file);
              }}
            />
            
            <div className="space-y-4">
              <div className="flex justify-center">
                {verificationStatus === 'pending' && <Upload className="h-12 w-12 text-gray-400" />}
                {verificationStatus === 'verified' && <CheckCircle className="h-12 w-12 text-green-500" />}
                {verificationStatus === 'failed' && <AlertCircle className="h-12 w-12 text-red-500" />}
              </div>
              
              <div className="space-y-2">
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={scanning}
                >
                  <Camera className="h-5 w-5 mr-2" />
                  {scanning ? 'Scanning...' : 'Upload Receipt'}
                </Button>
                <p className="text-sm text-gray-400">
                  or drag and drop your receipt here
                </p>
              </div>
            </div>
          </div>

          {/* Results */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
              <p className="text-red-500">{error}</p>
            </div>
          )}

          {result && (
            <div className="bg-dark-700 rounded-lg p-4">
              <h4 className="text-lg font-medium text-white mb-2">Scanned Content</h4>
              <pre className="text-sm text-gray-400 whitespace-pre-wrap">{result}</pre>
            </div>
          )}
        </div>

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </Card>
  );
}