import React from 'react';
import { Calendar } from 'lucide-react';

interface RevenueData {
  date: string;
  revenue: number;
  transactions: number;
}

export function RevenueChart() {
  const timeRanges = ['Daily', 'Weekly', 'Monthly', 'Yearly'];
  const [selectedRange, setSelectedRange] = React.useState('Weekly');

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Calendar className="h-5 w-5 text-brand-500 mr-2" />
          <h3 className="text-lg font-medium">Revenue Overview</h3>
        </div>
        <div className="flex space-x-2">
          {timeRanges.map((range) => (
            <button
              key={range}
              onClick={() => setSelectedRange(range)}
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                selectedRange === range
                  ? 'bg-brand-500 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>
      
      <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
        {/* Chart placeholder - In production, integrate with a charting library */}
        <p className="text-gray-500">Revenue Chart</p>
      </div>
      
      <div className="grid grid-cols-3 gap-4 mt-6">
        <div className="bg-gray-50 rounded-lg p-4">
          <p className="text-sm text-gray-600">Total Revenue</p>
          <p className="text-xl font-bold text-gray-900">R245,000</p>
        </div>
        <div className="bg-gray-50 rounded-lg p-4">
          <p className="text-sm text-gray-600">Transactions</p>
          <p className="text-xl font-bold text-gray-900">1,234</p>
        </div>
        <div className="bg-gray-50 rounded-lg p-4">
          <p className="text-sm text-gray-600">Average Value</p>
          <p className="text-xl font-bold text-gray-900">R198.54</p>
        </div>
      </div>
    </div>
  );
}