import React from 'react';
import { Users } from 'lucide-react';

interface CustomerSegment {
  tier: string;
  count: number;
  spending: number;
  retention: number;
  color: string;
}

export function CustomerSegmentation() {
  const segments: CustomerSegment[] = [
    {
      tier: 'Platinum',
      count: 124,
      spending: 12500,
      retention: 95,
      color: 'bg-purple-500'
    },
    {
      tier: 'Gold',
      count: 356,
      spending: 7500,
      retention: 85,
      color: 'bg-yellow-500'
    },
    {
      tier: 'Silver',
      count: 892,
      spending: 3500,
      retention: 75,
      color: 'bg-gray-400'
    },
    {
      tier: 'Bronze',
      count: 2341,
      spending: 1200,
      retention: 60,
      color: 'bg-orange-600'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center mb-6">
        <Users className="h-5 w-5 text-brand-500 mr-2" />
        <h3 className="text-lg font-medium">Customer Segments</h3>
      </div>

      <div className="space-y-4">
        {segments.map((segment) => (
          <div key={segment.tier} className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full ${segment.color} mr-2`} />
                <h4 className="font-medium">{segment.tier}</h4>
              </div>
              <span className="text-sm text-gray-600">
                {segment.count} customers
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-3">
              <div>
                <p className="text-sm text-gray-600">Avg. Monthly Spend</p>
                <p className="text-lg font-semibold">R{segment.spending}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Retention Rate</p>
                <p className="text-lg font-semibold">{segment.retention}%</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}