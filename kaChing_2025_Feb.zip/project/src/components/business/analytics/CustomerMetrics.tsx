import React from 'react';
import { Users, TrendingUp, ShoppingBag } from 'lucide-react';

interface CustomerMetric {
  label: string;
  value: number;
  trend: number;
  icon: React.ReactNode;
}

export function CustomerMetrics() {
  const metrics: CustomerMetric[] = [
    {
      label: 'Daily Active Users',
      value: 234,
      trend: 12.5,
      icon: <Users className="h-6 w-6 text-brand-500" />
    },
    {
      label: 'Average Transaction',
      value: 450,
      trend: 8.3,
      icon: <ShoppingBag className="h-6 w-6 text-brand-500" />
    },
    {
      label: 'Customer Retention',
      value: 85,
      trend: 3.2,
      icon: <TrendingUp className="h-6 w-6 text-brand-500" />
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {metrics.map((metric) => (
        <div key={metric.label} className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            {metric.icon}
            <span className={`text-sm font-medium ${
              metric.trend > 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {metric.trend > 0 ? '+' : ''}{metric.trend}%
            </span>
          </div>
          <h3 className="text-lg font-medium text-gray-900">{metric.label}</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            {metric.label.includes('Transaction') ? 'R' : ''}{metric.value}
            {metric.label.includes('Retention') ? '%' : ''}
          </p>
        </div>
      ))}
    </div>
  );
}