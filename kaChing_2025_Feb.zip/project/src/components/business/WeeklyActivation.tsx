import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Zap, Users, TrendingUp, Target, Calendar, AlertCircle, CheckCircle, Info } from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';

interface BookingSlot {
  id: number;
  date: string;
  slots: number;
  participants: number;
  costPerBusiness: number;
}

export function WeeklyActivation() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'book'>('overview');
  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  const stats = {
    participatingCustomers: 856,
    totalSpent: 245000,
    averageTransaction: 286,
    conversionRate: 18.5
  };

  const availableWeeks: BookingSlot[] = [
    { id: 1, date: '2024-03-25', slots: 5, participants: 0, costPerBusiness: 3000 },
    { id: 2, date: '2024-04-01', slots: 3, participants: 2, costPerBusiness: 2500 },
    { id: 3, date: '2024-04-08', slots: 8, participants: 0, costPerBusiness: 3000 },
    { id: 4, date: '2024-04-15', slots: 4, participants: 1, costPerBusiness: 3000 }
  ];

  const campaignCosts = {
    socialMedia: 7500,
    prizePool: 5000,
    management: 2500,
    total: 15000
  };

  const handleBookSlot = (slotId: number) => {
    setSelectedSlot(slotId);
  };

  const handleConfirmBooking = () => {
    setBookingConfirmed(true);
    setTimeout(() => {
      navigate('/payment');
    }, 1500);
  };

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Zap className="h-8 w-8 text-brand-500 mr-3" />
            <h2 className="text-2xl font-bold text-white">Weekly R5000 Activation</h2>
          </div>
          <div className="flex space-x-2">
            <Button
              variant={activeTab === 'overview' ? 'primary' : 'outline'}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </Button>
            <Button
              variant={activeTab === 'book' ? 'primary' : 'outline'}
              onClick={() => setActiveTab('book')}
            >
              Book Space
            </Button>
          </div>
        </div>

        {activeTab === 'overview' ? (
          <div className="space-y-6">
            <div className="bg-dark-700 p-4 rounded-lg mb-6">
              <div className="flex items-center mb-2">
                <Info className="h-5 w-5 text-brand-500 mr-2" />
                <h3 className="text-lg font-semibold text-white">Campaign Overview</h3>
              </div>
              <p className="text-gray-400">
                Join our weekly R5000 activation campaign to boost customer engagement and drive sales.
                Each participating business shares the campaign costs while benefiting from increased visibility
                and customer participation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-dark-700 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Participating Customers</p>
                    <h3 className="text-2xl font-bold text-white">{stats.participatingCustomers}</h3>
                  </div>
                  <Users className="h-8 w-8 text-brand-500" />
                </div>
              </div>
              <div className="bg-dark-700 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Total Spent</p>
                    <h3 className="text-2xl font-bold text-white">R{stats.totalSpent.toLocaleString()}</h3>
                  </div>
                  <TrendingUp className="h-8 w-8 text-brand-500" />
                </div>
              </div>
              <div className="bg-dark-700 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Average Transaction</p>
                    <h3 className="text-2xl font-bold text-white">R{stats.averageTransaction}</h3>
                  </div>
                  <Target className="h-8 w-8 text-brand-500" />
                </div>
              </div>
              <div className="bg-dark-700 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Conversion Rate</p>
                    <h3 className="text-2xl font-bold text-white">{stats.conversionRate}%</h3>
                  </div>
                  <CheckCircle className="h-8 w-8 text-brand-500" />
                </div>
              </div>
            </div>

            <div className="bg-dark-700 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-white mb-4">Campaign Cost Breakdown</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-gray-400">Social Media Campaign</span>
                    <p className="text-sm text-gray-500">Content creation and targeted ads</p>
                  </div>
                  <span className="text-white">R{campaignCosts.socialMedia.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-gray-400">Prize Pool</span>
                    <p className="text-sm text-gray-500">R5000 shopping voucher</p>
                  </div>
                  <span className="text-white">R{campaignCosts.prizePool.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-gray-400">Campaign Management</span>
                    <p className="text-sm text-gray-500">Coordination and reporting</p>
                  </div>
                  <span className="text-white">R{campaignCosts.management.toLocaleString()}</span>
                </div>
                <div className="border-t border-dark-600 pt-4 flex justify-between items-center">
                  <span className="font-semibold text-white">Total Campaign Cost</span>
                  <span className="font-semibold text-white">R{campaignCosts.total.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-dark-700 p-4 rounded-lg mb-4">
              <div className="flex items-center mb-2">
                <Info className="h-5 w-5 text-brand-500 mr-2" />
                <h3 className="text-lg font-semibold text-white">Booking Information</h3>
              </div>
              <p className="text-gray-400 mb-2">
                Cost per business varies based on the number of participants:
              </p>
              <ul className="list-disc list-inside text-gray-400 space-y-1">
                <li>5 businesses: R3,000 each</li>
                <li>6 businesses: R2,500 each</li>
              </ul>
            </div>

            <div className="grid gap-4">
              {availableWeeks.map((week) => (
                <div
                  key={week.id}
                  className={`bg-dark-700 p-4 rounded-lg cursor-pointer transition-colors ${
                    selectedSlot === week.id ? 'ring-2 ring-brand-500' : 'hover:bg-dark-600'
                  }`}
                  onClick={() => handleBookSlot(week.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Calendar className="h-6 w-6 text-brand-500" />
                      <div>
                        <p className="text-white font-medium">
                          Week of {new Date(week.date).toLocaleDateString()}
                        </p>
                        <p className="text-sm text-gray-400">
                          {week.slots - week.participants} slots available
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">
                        R{week.costPerBusiness.toLocaleString()} per business
                      </p>
                      <p className="text-sm text-gray-400">
                        {week.participants} participants
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {selectedSlot && (
              <div className="flex justify-end">
                <Button
                  variant="primary"
                  size="lg"
                  onClick={handleConfirmBooking}
                  disabled={bookingConfirmed}
                >
                  {bookingConfirmed ? 'Redirecting to Payment...' : 'Confirm Booking'}
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}