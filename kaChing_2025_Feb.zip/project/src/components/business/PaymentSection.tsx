import React from 'react';
import { CreditCard, DollarSign, Receipt } from 'lucide-react';
import { Card } from '../shared/Card';
import type { PaymentHistory } from '../../types/payment';

export function PaymentSection() {
  const paymentStats = {
    totalRevenue: 245000,
    pendingPayouts: 12500,
    nextPayout: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  };

  const recentTransactions: PaymentHistory[] = [
    {
      id: '1',
      date: new Date().toISOString(),
      amount: 2500,
      description: 'Weekly Payout',
      status: 'completed',
      paymentMethod: 'Bank Transfer'
    },
    {
      id: '2',
      date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      amount: 3200,
      description: 'Weekly Payout',
      status: 'completed',
      paymentMethod: 'Bank Transfer'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Revenue</p>
                <h3 className="text-2xl font-bold text-white mt-1">
                  R{paymentStats.totalRevenue.toLocaleString()}
                </h3>
              </div>
              <DollarSign className="h-8 w-8 text-brand-500" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Pending Payouts</p>
                <h3 className="text-2xl font-bold text-white mt-1">
                  R{paymentStats.pendingPayouts.toLocaleString()}
                </h3>
              </div>
              <Receipt className="h-8 w-8 text-brand-500" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Next Payout Date</p>
                <h3 className="text-lg font-bold text-white mt-1">
                  {paymentStats.nextPayout.toLocaleDateString()}
                </h3>
              </div>
              <CreditCard className="h-8 w-8 text-brand-500" />
            </div>
          </div>
        </Card>
      </div>

      <Card>
        <div className="p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Recent Transactions</h3>
          <div className="space-y-4">
            {recentTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-4 bg-dark-700 rounded-lg"
              >
                <div>
                  <p className="text-white font-medium">{transaction.description}</p>
                  <p className="text-sm text-gray-400">
                    {new Date(transaction.date).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-white font-medium">
                    R{transaction.amount.toLocaleString()}
                  </p>
                  <p className="text-sm text-green-500">
                    {transaction.status}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      <Card>
        <div className="p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Payment Settings</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
              <div>
                <p className="text-white font-medium">Bank Account</p>
                <p className="text-sm text-gray-400">**** 1234</p>
              </div>
              <button className="text-brand-500 hover:text-brand-400">
                Update
              </button>
            </div>
            <div className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
              <div>
                <p className="text-white font-medium">Payout Schedule</p>
                <p className="text-sm text-gray-400">Weekly</p>
              </div>
              <button className="text-brand-500 hover:text-brand-400">
                Change
              </button>
            </div>
            <div className="flex items-center justify-between p-4 bg-dark-700 rounded-lg">
              <div>
                <p className="text-white font-medium">Tax Information</p>
                <p className="text-sm text-gray-400">VAT Number: 123456789</p>
              </div>
              <button className="text-brand-500 hover:text-brand-400">
                Edit
              </button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}