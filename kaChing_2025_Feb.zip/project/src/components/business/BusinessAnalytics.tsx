import React from 'react';
import { CustomerMetrics } from './analytics/CustomerMetrics';
import { RevenueChart } from './analytics/RevenueChart';
import { CustomerSegmentation } from './analytics/CustomerSegmentation';

export function BusinessAnalytics() {
  return (
    <div className="space-y-8">
      {/* Key Metrics */}
      <CustomerMetrics />
      
      {/* Revenue Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <RevenueChart />
        </div>
        <div>
          <CustomerSegmentation />
        </div>
      </div>
    </div>
  );
}