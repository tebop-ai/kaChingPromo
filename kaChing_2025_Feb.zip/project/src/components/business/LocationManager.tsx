import React, { useState } from 'react';
import { MapPin, Plus, Trash2 } from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import type { BusinessLocation } from '../../types/location';
import { useBusinessLocations } from '../../hooks/useBusinessLocations';

export function LocationManager() {
  const { locations, loading } = useBusinessLocations();
  const [showAddForm, setShowAddForm] = useState(false);

  const handleAddLocation = () => {
    setShowAddForm(true);
  };

  const handleDeleteLocation = (location: BusinessLocation) => {
    // In production, this would call an API
    console.log('Deleting location:', location);
  };

  if (loading) {
    return <div>Loading locations...</div>;
  }

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <MapPin className="h-6 w-6 text-brand-500 mr-2" />
            <h3 className="text-xl font-semibold text-white">Business Locations</h3>
          </div>
          <Button variant="outline" onClick={handleAddLocation}>
            <Plus className="h-4 w-4 mr-2" />
            Add Location
          </Button>
        </div>

        <div className="space-y-4">
          {locations.map((location, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-dark-700 rounded-lg"
            >
              <div>
                <p className="text-white font-medium">{location.address}</p>
                <p className="text-sm text-gray-400">
                  Ward {location.ward.name}, {location.ward.municipality}
                </p>
                <p className="text-sm text-gray-400">
                  {location.ward.province}
                </p>
                {location.isPrimary && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-brand-500/10 text-brand-500 mt-2">
                    Primary Location
                  </span>
                )}
              </div>
              <button
                onClick={() => handleDeleteLocation(location)}
                className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                disabled={location.isPrimary}
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>

        {showAddForm && (
          <div className="mt-6 p-4 bg-dark-700 rounded-lg">
            <h4 className="text-lg font-medium text-white mb-4">Add New Location</h4>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Street Address
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 rounded-lg bg-dark-800 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Province
                  </label>
                  <select className="w-full px-4 py-2 rounded-lg bg-dark-800 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Select Province</option>
                    <option value="gauteng">Gauteng</option>
                    <option value="western-cape">Western Cape</option>
                    {/* Add other provinces */}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Municipality
                  </label>
                  <select className="w-full px-4 py-2 rounded-lg bg-dark-800 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500">
                    <option value="">Select Municipality</option>
                    {/* Municipalities would be populated based on selected province */}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Ward
                </label>
                <select className="w-full px-4 py-2 rounded-lg bg-dark-800 border border-dark-600 text-white focus:outline-none focus:ring-2 focus:ring-brand-500">
                  <option value="">Select Ward</option>
                  {/* Wards would be populated based on selected municipality */}
                </select>
              </div>

              <div className="flex justify-end space-x-4">
                <Button variant="outline" onClick={() => setShowAddForm(false)}>
                  Cancel
                </Button>
                <Button variant="primary" type="submit">
                  Add Location
                </Button>
              </div>
            </form>
          </div>
        )}
      </div>
    </Card>
  );
}