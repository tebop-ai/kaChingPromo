import React from 'react';
import { Calendar, Users, TrendingUp } from 'lucide-react';
import type { Campaign } from '../../types/business';

export function CampaignList() {
  const campaigns: Campaign[] = [
    {
      id: '1',
      title: 'Summer Shopping Spree',
      description: 'Double points on all purchases above R500',
      startDate: '2024-03-01',
      endDate: '2024-03-31',
      budget: 50000,
      targetAudience: ['Silver', 'Gold'],
      rewards: [],
      status: 'active',
      performance: {
        reach: 5000,
        engagement: 2500,
        redemptions: 750,
        roi: 2.5
      }
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Active Campaigns</h2>
        <button className="bg-brand-600 text-white px-4 py-2 rounded-md hover:bg-brand-700 transition-colors">
          Create Campaign
        </button>
      </div>

      <div className="space-y-4">
        {campaigns.map((campaign) => (
          <div key={campaign.id} className="border rounded-lg p-4">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-medium text-lg">{campaign.title}</h3>
                <p className="text-gray-600">{campaign.description}</p>
              </div>
              <span className="px-3 py-1 rounded-full text-sm bg-green-100 text-green-800">
                {campaign.status}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 text-brand-500 mr-2" />
                <span className="text-sm">
                  {new Date(campaign.startDate).toLocaleDateString()} - 
                  {new Date(campaign.endDate).toLocaleDateString()}
                </span>
              </div>

              <div className="flex items-center">
                <Users className="h-5 w-5 text-brand-500 mr-2" />
                <span className="text-sm">
                  Reach: {campaign.performance.reach.toLocaleString()}
                </span>
              </div>

              <div className="flex items-center">
                <TrendingUp className="h-5 w-5 text-brand-500 mr-2" />
                <span className="text-sm">
                  ROI: {campaign.performance.roi}x
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}