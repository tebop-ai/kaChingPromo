import React from 'react';
import { TrendingUp, Users, ShoppingBag, Target } from 'lucide-react';
import { BusinessAnalytics } from '../../components/business/BusinessAnalytics';
import { CampaignList } from '../../components/business/CampaignList';
import { RewardManager } from '../../components/business/RewardManager';

export function BusinessDashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Total Revenue</p>
              <h3 className="text-2xl font-bold text-white">R245,000</h3>
              <p className="text-sm text-brand-500">+12.5% from last month</p>
            </div>
            <TrendingUp className="h-8 w-8 text-brand-500" />
          </div>
        </div>

        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Active Customers</p>
              <h3 className="text-2xl font-bold text-white">1,234</h3>
              <p className="text-sm text-brand-500">+5.3% from last month</p>
            </div>
            <Users className="h-8 w-8 text-brand-500" />
          </div>
        </div>

        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Rewards Redeemed</p>
              <h3 className="text-2xl font-bold text-white">456</h3>
              <p className="text-sm text-brand-500">+8.7% from last month</p>
            </div>
            <ShoppingBag className="h-8 w-8 text-brand-500" />
          </div>
        </div>

        <div className="bg-dark-800 border border-dark-700 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Conversion Rate</p>
              <h3 className="text-2xl font-bold text-white">23.5%</h3>
              <p className="text-sm text-brand-500">+2.1% from last month</p>
            </div>
            <Target className="h-8 w-8 text-brand-500" />
          </div>
        </div>
      </div>

      {/* Analytics Section */}
      <div className="mb-8">
        <BusinessAnalytics />
      </div>

      {/* Active Campaigns */}
      <div className="mb-8">
        <CampaignList />
      </div>

      {/* Reward Management */}
      <div>
        <RewardManager />
      </div>
    </div>
  );
}