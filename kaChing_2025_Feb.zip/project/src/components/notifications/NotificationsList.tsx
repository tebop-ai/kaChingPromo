import React from 'react';
import { Gift, Tag, AlertCircle, Info } from 'lucide-react';
import type { Notification, NotificationType } from '../../types/notifications';

interface NotificationsListProps {
  selectedTypes: NotificationType[];
}

export function NotificationsList({ selectedTypes }: NotificationsListProps) {
  const notifications: Notification[] = [
    {
      id: '1',
      type: 'reward',
      title: 'New Reward Available',
      message: 'You\'ve unlocked a new reward! R200 off your next purchase at Woolworths.',
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      read: false,
      actionUrl: '/rewards/1',
    },
    {
      id: '2',
      type: 'offer',
      title: 'Limited Time Offer',
      message: 'Double points on all purchases this weekend!',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      read: true,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 48).toISOString(),
    },
    {
      id: '3',
      type: 'alert',
      title: 'Points Milestone Reached',
      message: 'Congratulations! You\'ve reached 5000 points.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      read: false,
    },
  ];

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case 'reward':
        return <Gift className="h-6 w-6 text-brand-500" />;
      case 'offer':
        return <Tag className="h-6 w-6 text-green-500" />;
      case 'alert':
        return <AlertCircle className="h-6 w-6 text-yellow-500" />;
      default:
        return <Info className="h-6 w-6 text-blue-500" />;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 1000 * 60 * 60) {
      const minutes = Math.floor(diff / (1000 * 60));
      return `${minutes}m ago`;
    } else if (diff < 1000 * 60 * 60 * 24) {
      const hours = Math.floor(diff / (1000 * 60 * 60));
      return `${hours}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const filteredNotifications = selectedTypes.length > 0
    ? notifications.filter(n => selectedTypes.includes(n.type))
    : notifications;

  return (
    <div className="divide-y divide-dark-700">
      {filteredNotifications.map((notification) => (
        <div
          key={notification.id}
          className={`p-4 hover:bg-dark-700/50 transition-colors ${
            !notification.read ? 'bg-dark-700/20' : ''
          }`}
        >
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              {getIcon(notification.type)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-white">
                  {notification.title}
                </p>
                <span className="text-xs text-gray-400">
                  {formatTimestamp(notification.timestamp)}
                </span>
              </div>
              <p className="text-sm text-gray-400 mt-1">
                {notification.message}
              </p>
              {notification.actionUrl && (
                <a
                  href={notification.actionUrl}
                  className="inline-block mt-2 text-sm text-brand-500 hover:text-brand-400"
                >
                  View Details →
                </a>
              )}
              {notification.expiresAt && (
                <p className="text-xs text-gray-500 mt-2">
                  Expires {new Date(notification.expiresAt).toLocaleDateString()}
                </p>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}