import React from 'react';
import { Gift, Tag, AlertCircle, Info } from 'lucide-react';
import type { NotificationType } from '../../types/notifications';

interface NotificationFiltersProps {
  selectedTypes: NotificationType[];
  onTypeSelect: (types: NotificationType[]) => void;
}

export function NotificationFilters({ selectedTypes, onTypeSelect }: NotificationFiltersProps) {
  const filters: Array<{
    type: NotificationType;
    label: string;
    icon: React.ReactNode;
  }> = [
    { type: 'reward', label: 'Rewards', icon: <Gift className="h-4 w-4" /> },
    { type: 'offer', label: 'Offers', icon: <Tag className="h-4 w-4" /> },
    { type: 'alert', label: 'Alerts', icon: <AlertCircle className="h-4 w-4" /> },
    { type: 'system', label: 'System', icon: <Info className="h-4 w-4" /> },
  ];

  const toggleFilter = (type: NotificationType) => {
    if (selectedTypes.includes(type)) {
      onTypeSelect(selectedTypes.filter(t => t !== type));
    } else {
      onTypeSelect([...selectedTypes, type]);
    }
  };

  return (
    <div className="p-4 border-b border-dark-700">
      <div className="flex flex-wrap gap-2">
        {filters.map(({ type, label, icon }) => (
          <button
            key={type}
            onClick={() => toggleFilter(type)}
            className={`inline-flex items-center px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
              selectedTypes.includes(type)
                ? 'bg-brand-500 text-white'
                : 'bg-dark-700 text-gray-300 hover:bg-dark-600'
            }`}
          >
            <span className="mr-1.5">{icon}</span>
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}