import React, { useState } from 'react';
import { Bell, Moon, Mail, Smartphone } from 'lucide-react';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import type { NotificationPreferences } from '../../types/notifications';

export function NotificationPreferencesPanel() {
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    doNotDisturb: false,
    categories: {
      reward: true,
      offer: true,
      alert: true,
      system: true,
    },
    emailNotifications: true,
    pushNotifications: true,
  });

  const handleToggle = (key: keyof NotificationPreferences | keyof NotificationPreferences['categories']) => {
    setPreferences(prev => {
      if (key in prev.categories) {
        return {
          ...prev,
          categories: {
            ...prev.categories,
            [key]: !prev.categories[key as keyof typeof prev.categories],
          },
        };
      }
      return {
        ...prev,
        [key]: !prev[key as keyof NotificationPreferences],
      };
    });
  };

  return (
    <Card>
      <div className="p-6 space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Notification Preferences</h3>
          
          {/* Do Not Disturb */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Moon className="h-5 w-5 text-brand-500 mr-2" />
              <span className="text-white">Do Not Disturb</span>
            </div>
            <div className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={preferences.doNotDisturb}
                onChange={() => handleToggle('doNotDisturb')}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-dark-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-500/25 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-500"></div>
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-400">Categories</h4>
            {Object.entries(preferences.categories).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-white capitalize">{key}</span>
                <div className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={value}
                    onChange={() => handleToggle(key as keyof typeof preferences.categories)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-dark-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-500/25 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-500"></div>
                </div>
              </div>
            ))}
          </div>

          {/* Delivery Methods */}
          <div className="mt-6 space-y-4">
            <h4 className="text-sm font-medium text-gray-400">Delivery Methods</h4>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Mail className="h-5 w-5 text-brand-500 mr-2" />
                <span className="text-white">Email Notifications</span>
              </div>
              <div className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.emailNotifications}
                  onChange={() => handleToggle('emailNotifications')}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-dark-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-500/25 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-500"></div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Smartphone className="h-5 w-5 text-brand-500 mr-2" />
                <span className="text-white">Push Notifications</span>
              </div>
              <div className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.pushNotifications}
                  onChange={() => handleToggle('pushNotifications')}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-dark-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-500/25 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-500"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <Button variant="primary">Save Preferences</Button>
        </div>
      </div>
    </Card>
  );
}