export type NotificationType = 'reward' | 'offer' | 'alert' | 'system';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actionUrl?: string;
  expiresAt?: string;
  icon?: string;
}

export interface NotificationPreferences {
  doNotDisturb: boolean;
  categories: {
    [key in NotificationType]: boolean;
  };
  emailNotifications: boolean;
  pushNotifications: boolean;
}