export interface User {
  id: string;
  name: string;
  email: string;
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  spendingMilestones: {
    current: number;
    target: number;
  };
  preferences: string[];
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  pointsCost: number;
  category: 'Shopping' | 'Dining' | 'Travel' | 'Entertainment' | 'Charity';
  merchant: string;
  imageUrl: string;
  expiryDate?: string;
  featured?: boolean;
  location?: string;
  milestone?: number;
}

export interface Transaction {
  id: string;
  amount: number;
  pointsEarned: number;
  merchant: string;
  date: string;
  category: string;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  target: number;
  progress: number;
  reward: number;
  expiryDate: string;
  category: string;
}