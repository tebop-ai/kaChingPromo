export interface WeeklyParticipant {
  id: string;
  businessName: string;
  description: string;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  category: string;
  hours: string;
  isOpen: boolean;
  website?: string;
  distance?: number;
}