export interface Ward {
  code: string;
  name: string;
  municipality: string;
  district: string;
  province: string;
}

export interface BusinessLocation {
  ward: Ward;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  isPrimary: boolean;
}

export interface LocationFilters {
  province?: string;
  district?: string;
  municipality?: string;
  ward?: string;
}