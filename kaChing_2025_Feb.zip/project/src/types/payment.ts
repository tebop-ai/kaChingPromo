import type { User } from './index';

export interface PaymentMethod {
  id: string;
  type: 'card';
  last4: string;
  brand: string;
  expiryMonth: number;
  expiryYear: number;
  isDefault: boolean;
}

export interface BillingAddress {
  street: string;
  city: string;
  province: string;
  postalCode: string;
  country: string;
}

export interface PaymentHistory {
  id: string;
  date: string;
  amount: number;
  description: string;
  status: 'completed' | 'pending' | 'failed';
  paymentMethod: string;
}

export interface PaymentProfile {
  user: User;
  paymentMethods: PaymentMethod[];
  billingAddress?: BillingAddress;
  paymentHistory: PaymentHistory[];
}