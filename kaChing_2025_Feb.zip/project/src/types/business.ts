import type { BusinessLocation } from './location';
import type { Reward } from './index';

export interface BusinessProfile {
  id: string;
  name: string;
  description: string;
  logo: string;
  category: string;
  locations: BusinessLocation[];
  rewardsBudget: number;
  pointsMultiplier: number;
}

// Rest of the file remains the same...