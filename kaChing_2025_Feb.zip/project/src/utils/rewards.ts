import type { Transaction, User } from '../types';

export const calculatePoints = (amount: number): number => {
  // Base rate: 1 point per R1
  let points = Math.floor(amount);
  
  // Bonus points for spending thresholds
  if (amount >= 1000) points += 500;
  else if (amount >= 500) points += 200;
  else if (amount >= 200) points += 50;
  
  return points;
};

export const calculateTier = (totalSpent: number): User['tier'] => {
  if (totalSpent >= 50000) return 'Platinum';
  if (totalSpent >= 25000) return 'Gold';
  if (totalSpent >= 10000) return 'Silver';
  return 'Bronze';
};

export const getNextTierProgress = (totalSpent: number): { next: User['tier'], remaining: number } => {
  if (totalSpent < 10000) return { next: 'Silver', remaining: 10000 - totalSpent };
  if (totalSpent < 25000) return { next: 'Gold', remaining: 25000 - totalSpent };
  if (totalSpent < 50000) return { next: 'Platinum', remaining: 50000 - totalSpent };
  return { next: 'Platinum', remaining: 0 };
};

export const getMilestoneProgress = (transactions: Transaction[]): number => {
  const thisMonth = new Date().getMonth();
  const thisMonthSpending = transactions
    .filter(t => new Date(t.date).getMonth() === thisMonth)
    .reduce((sum, t) => sum + t.amount, 0);
  return thisMonthSpending;
};