import * as tf from '@tensorflow/tfjs';

export async function validateReceiptImage(imageData: ImageData): Promise<{
  isValid: boolean;
  confidence: number;
  issues?: string[];
}> {
  const issues: string[] = [];
  let confidence = 0;

  try {
    // Convert image to tensor
    const tensor = tf.browser.fromPixels(imageData, 1);
    const normalized = tensor.div(255.0);

    // Check image quality
    const { mean, variance } = tf.moments(normalized);
    const meanValue = mean.dataSync()[0];
    const varianceValue = variance.dataSync()[0];

    // Image quality checks
    if (meanValue < 0.2) {
      issues.push('Image too dark');
      confidence -= 0.2;
    }
    if (varianceValue < 0.1) {
      issues.push('Low image contrast');
      confidence -= 0.2;
    }

    // Check for digital manipulation
    const edges = tf.conv2d(
      normalized.expandDims(0).expandDims(-1),
      tf.randomNormal([3, 3, 1, 1]),
      1,
      'valid'
    );
    
    const edgeVariance = tf.moments(edges).variance.dataSync()[0];
    if (edgeVariance < 0.05) {
      issues.push('Potential digital manipulation detected');
      confidence -= 0.4;
    }

    // Clean up tensors
    tensor.dispose();
    normalized.dispose();
    edges.dispose();

    // Calculate final confidence
    confidence = Math.max(0, 1 + confidence);

    return {
      isValid: confidence > 0.6,
      confidence,
      issues: issues.length > 0 ? issues : undefined
    };
  } catch (error) {
    console.error('Receipt validation error:', error);
    return {
      isValid: false,
      confidence: 0,
      issues: ['Failed to validate receipt image']
    };
  }
}

export function extractReceiptData(text: string) {
  const lines = text.split('\n');
  const data = {
    date: '',
    total: 0,
    merchant: '',
    items: [] as { name: string; price: number }[],
  };

  // Extract date
  const dateMatch = text.match(/\d{1,2}[-/]\d{1,2}[-/]\d{2,4}/);
  if (dateMatch) {
    data.date = dateMatch[0];
  }

  // Extract merchant name (usually in the first few lines)
  for (let i = 0; i < Math.min(3, lines.length); i++) {
    if (lines[i].length > 3 && !/total|date|tel|address/i.test(lines[i])) {
      data.merchant = lines[i].trim();
      break;
    }
  }

  // Extract total amount
  const totalMatch = text.match(/total[:\s]*R?\s*(\d+([.,]\d{2})?)/i);
  if (totalMatch) {
    data.total = parseFloat(totalMatch[1].replace(',', '.'));
  }

  // Extract items (looking for price patterns)
  const itemPattern = /(.+?)\s+R?\s*(\d+([.,]\d{2})?)\s*$/;
  lines.forEach(line => {
    const match = line.match(itemPattern);
    if (match && !line.toLowerCase().includes('total')) {
      data.items.push({
        name: match[1].trim(),
        price: parseFloat(match[2].replace(',', '.')),
      });
    }
  });

  return data;
}