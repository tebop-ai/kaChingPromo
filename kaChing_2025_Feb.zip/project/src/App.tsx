import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Browse } from './pages/Browse';
import { Home } from './pages/Home';
import { Profile } from './pages/Profile';
import { Payment } from './pages/Payment';
import { CommunityHub } from './pages/CommunityHub';
import { Notifications } from './pages/Notifications';
import { WeeklyParticipants } from './pages/WeeklyParticipants';
import { BusinessDashboard } from './pages/business/Dashboard';
import { BusinessProfile } from './pages/business/Profile';
import { ListBusiness } from './pages/business/ListBusiness';
import { Header } from './components/Header';
import { useAuth } from './hooks/useAuth';

function App() {
  const { user } = useAuth();
  const isBusinessUser = user && 'businessProfile' in user;

  return (
    <Router>
      <div className="min-h-screen bg-dark-900">
        {user && <Header />}
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/browse" element={<Browse />} />
          <Route path="/weekly-participants" element={<WeeklyParticipants />} />
          <Route path="/community" element={<CommunityHub />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/business" element={<ListBusiness />} />
          <Route path="/payment" element={user ? <Payment /> : <Navigate to="/login" />} />
          <Route 
            path="/business/dashboard" 
            element={
              isBusinessUser ? (
                <BusinessDashboard />
              ) : (
                <Navigate to="/business" replace />
              )
            } 
          />
          <Route 
            path="/business/profile" 
            element={
              isBusinessUser ? (
                <BusinessProfile />
              ) : (
                <Navigate to="/business" replace />
              )
            } 
          />
          <Route 
            path="/dashboard" 
            element={
              user && !isBusinessUser ? (
                <Home />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
          <Route 
            path="/profile" 
            element={
              user ? <Profile /> : <Navigate to="/" replace />
            } 
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;